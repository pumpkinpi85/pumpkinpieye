This is the Stage 4 addition for pi-gen to install PumpkinPiEye.
Place the `stage4-pumpkinpieye` folder inside the pi-gen directory as `stage4/` or append to an existing stage4 build.

Make sure the main `config` file in pi-gen is configured properly before running:
IMG_NAME="pumpkinpieye"
FIRST_USER_NAME=pi
FIRST_USER_PASS=raspberry
ENABLE_SSH=1
